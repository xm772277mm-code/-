# NawaCore-50M Windows EXE Build Kit
تم تصدير هذا المشروع مباشرة من NawaCore Studio مع أوزان النموذج المدربة مسبقاً في `src/nawa_weights.h`.

## خطوات بناء ملف NawaAgent.exe
1. فك ضغط الملف على نظام Windows.
2. تأكد من وجود مترجم C++ (MinGW-w64 `g++` أو Visual Studio `cl.exe`).
3. شغّل `build_exe.bat` ليتم إنتاج `NawaAgent.exe` واختبار سرعة 50 مليون عملية/ثانية تلقائياً.
