@echo off
echo [NawaCore] Building standalone Windows NawaAgent.exe with AVX2 + O3 optimization...
where g++ >nul 2>nul
if %errorlevel%==0 (
  g++ -std=c++20 -O3 -mavx2 -mfma src\nawa_agent.cpp -o NawaAgent.exe
  if %errorlevel%==0 (
    echo [SUCCESS] Built NawaAgent.exe! Running 50M ops/sec verification:
    NawaAgent.exe --bench-only
    exit /b 0
  )
)
where cl >nul 2>nul
if %errorlevel%==0 (
  cl /std:c++20 /O2 /arch:AVX2 /EHsc src\nawa_agent.cpp /Fe:NawaAgent.exe
  NawaAgent.exe --bench-only
  exit /b 0
)
echo [ERROR] Please install MinGW-w64 (g++) or Visual Studio Build Tools (cl.exe) and re-run build_exe.bat
