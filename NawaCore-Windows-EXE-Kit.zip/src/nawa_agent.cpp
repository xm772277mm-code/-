#include "nawa_weights.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#if defined(__AVX2__)
#include <immintrin.h>
#endif

// FNV-1a 32-bit feature hashing matching NawaCore TypeScript/WASM tokenizer
static inline uint32_t fnv1a(const std::string& s, uint32_t seed) {
    uint32_t h = seed;
    for (unsigned char c : s) {
        h ^= c;
        h *= 16777619u;
    }
    return h;
}

static void featurize(const std::string& text, float* out_vec) {
    std::fill(out_vec, out_vec + NAWA_INPUT_DIM, 0.0f);
    std::string tok;
    auto add_feat = [&](const std::string& key, float w) {
        uint32_t h1 = fnv1a(key, 2166136261u);
        uint32_t h2 = fnv1a(key, 374761393u);
        uint32_t idx = h1 % NAWA_INPUT_DIM;
        float sign = (h2 & 1u) == 0 ? 1.0f : -1.0f;
        out_vec[idx] += sign * w;
    };
    for (size_t i = 0; i <= text.size(); ++i) {
        if (i == text.size() || text[i] == ' ' || text[i] == '\t' || text[i] == '\n') {
            if (!tok.empty()) {
                add_feat("W:" + tok, 1.0f);
                add_feat("C:" + tok, 2.0f);
                tok.clear();
            }
        } else {
            tok.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(text[i]))));
        }
    }
    float norm_sq = 0.0f;
    for (int i = 0; i < NAWA_INPUT_DIM; ++i) norm_sq += out_vec[i] * out_vec[i];
    float inv = norm_sq > 1e-8f ? 1.0f / std::sqrt(norm_sq) : 1.0f;
    for (int i = 0; i < NAWA_INPUT_DIM; ++i) out_vec[i] *= inv;
}

static void matvec_relu(const float* W, const float* x, const float* b, float* y, int rows, int cols, bool relu) {
    for (int i = 0; i < rows; ++i) {
        const float* row = W + i * cols;
        float sum = b[i];
#if defined(__AVX2__)
        __m256 acc = _mm256_setzero_ps();
        int j = 0;
        for (; j + 8 <= cols; j += 8) {
            __m256 wv = _mm256_loadu_ps(row + j);
            __m256 xv = _mm256_loadu_ps(x + j);
            acc = _mm256_add_ps(acc, _mm256_mul_ps(wv, xv));
        }
        alignas(32) float buf[8];
        _mm256_store_ps(buf, acc);
        for (int k = 0; k < 8; ++k) sum += buf[k];
        for (; j < cols; ++j) sum += row[j] * x[j];
#else
        for (int j = 0; j < cols; ++j) sum += row[j] * x[j];
#endif
        y[i] = (relu && sum < 0.0f) ? 0.0f : sum;
    }
}

static void run_50m_benchmark() {
    constexpr size_t N = 65536;
    constexpr int ROUNDS = 400; // 65536 * 2 * 400 = 52,428,800 ops
    std::vector<float> a(N, 1.001f), b(N, 0.999f);
    volatile float sink = 0.0f;

    auto t0 = std::chrono::high_resolution_clock::now();
    float acc0 = 0, acc1 = 0, acc2 = 0, acc3 = 0;
    for (int r = 0; r < ROUNDS; ++r) {
        for (size_t i = 0; i < N; i += 4) {
            acc0 += a[i] * b[i];
            acc1 += a[i + 1] * b[i + 1];
            acc2 += a[i + 2] * b[i + 2];
            acc3 += a[i + 3] * b[i + 3];
        }
    }
    sink = acc0 + acc1 + acc2 + acc3;
    auto t1 = std::chrono::high_resolution_clock::now();

    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    double total_ops = static_cast<double>(N) * 2.0 * ROUNDS;
    double ops_sec = (total_ops / ms) * 1000.0;
    std::cout << "[NawaCore Native EXE] Ops=" << static_cast<long long>(total_ops)
              << " | Elapsed=" << ms << " ms"
              << " | Throughput=" << static_cast<long long>(ops_sec) << " ops/sec"
              << " | Checksum=" << sink << std::endl;
}

int main(int argc, char** argv) {
    std::cout << "NawaCore-50M Standalone Native Engine (Zero External APIs)\n";
    run_50m_benchmark();

    if (argc > 1 && std::string(argv[1]) == "--bench-only") return 0;

    float x[NAWA_INPUT_DIM], h1[NAWA_H1_DIM], h2[NAWA_H2_DIM], out[NAWA_OUT_DIM];
    std::string line;
    std::cout << "\nEnter Arabic/English coding prompt (or 'exit'):\n> ";
    while (std::getline(std::cin, line)) {
        if (line == "exit" || line == "quit") break;
        featurize(line, x);
        auto t0 = std::chrono::high_resolution_clock::now();
        matvec_relu(NAWA_W1, x, NAWA_B1, h1, NAWA_H1_DIM, NAWA_INPUT_DIM, true);
        matvec_relu(NAWA_W2, h1, NAWA_B2, h2, NAWA_H2_DIM, NAWA_H1_DIM, true);
        matvec_relu(NAWA_W3, h2, NAWA_B3, out, NAWA_OUT_DIM, NAWA_H2_DIM, false);
        auto t1 = std::chrono::high_resolution_clock::now();

        int best = 0;
        for (int i = 1; i < NAWA_OUT_DIM; ++i) {
            if (out[i] > out[best]) best = i;
        }
        double us = std::chrono::duration<double, std::micro>(t1 - t0).count();
        std::cout << "Intent: " << NAWA_INTENTS[best] << " (" << us << " us)\n> ";
    }
    return 0;
}
