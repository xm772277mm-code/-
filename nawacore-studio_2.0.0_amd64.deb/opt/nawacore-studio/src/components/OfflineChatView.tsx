import React, { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, ChevronUp, Layers, Mic, MicOff, RotateCcw, Send, Square } from "lucide-react";

type ResponseStyle = "auto" | "simple" | "detailed" | "concise";

interface CompressionStats {
  enabled: boolean;
  activeTurnsInWindow: number;
  compressedTurns: number;
  savedRatioPct: number;
}

interface TokenCandidate {
  tokenId: number;
  token: string;
  prob: number;
}

interface NeuralTelemetry {
  modelName: string;
  totalParams: number;
  vocabSize: number;
  nLayers: number;
  nHeads: number;
  dModel: number;
  trainedEpochs: number;
  perplexity: number;
  generatedTokens: number;
  tokensPerSec: number;
  topStepCandidates: Array<{ chosen: string; chosenProb: number; alternatives: TokenCandidate[] }>;
  kvCompression: {
    enabled: boolean;
    activeKvSlots: number;
    compressedKvSlots: number;
    savedRatioPct: number;
  };
}

interface ChatEntry {
  id: string;
  role: "user" | "assistant";
  content: string;
  meta?: {
    dialect: string;
    topic: string | null;
    questionType?: string;
    attentionScore?: number;
    wasmMs: number;
    neural?: NeuralTelemetry;
  };
  suggestions?: string[];
  error?: string;
}

const QUESTION_TYPE_LABELS: Record<string, string> = {
  comparison: "مقارنة",
  how_to: "خطوات عملية",
  why_reason: "تحليل السبب",
  definition: "تعريف",
  code_review: "مراجعة كود",
  math: "حساب رياضي",
  summarize: "تلخيص",
  followup_simplify: "تبسيط",
  followup_example: "مثال تطبيقي",
  followup_detail: "تفصيل معمّق",
  greeting: "ترحيب",
  identity: "تعريف بالنموذج",
  creative: "صياغة",
  general: "حوار عام",
};

const DIALECT_VOICES = [
  { code: "ar-EG", label: "مصري" },
  { code: "ar-SA", label: "سعودي / خليجي" },
  { code: "ar-LB", label: "شامي" },
  { code: "ar-MA", label: "مغربي" },
  { code: "ar-IQ", label: "عراقي" },
];

const STARTER_PROMPTS = [
  "هل انت نموذج فعلي مش اسكربت",
  "قارن بين Python و Rust",
  "ازاي بيشتغل ضغط النشاط لتقليل اللاج",
  "احسب 50000000 / 22",
];

const UI_WINDOW_LIMIT = 8;

function renderInlineSegments(line: string) {
  const inlineParts = line.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return inlineParts.map((seg, sIdx) => {
    if (seg.startsWith("`") && seg.endsWith("`")) {
      return (
        <code
          key={sIdx}
          dir="ltr"
          className="mx-0.5 inline-block rounded bg-slate-800/90 px-1.5 py-0.5 font-mono text-xs text-blue-300"
        >
          {seg.slice(1, -1)}
        </code>
      );
    }
    if (seg.startsWith("**") && seg.endsWith("**")) {
      return (
        <strong key={sIdx} className="font-semibold text-white">
          {seg.slice(2, -2)}
        </strong>
      );
    }
    if (seg.startsWith("*") && seg.endsWith("*") && seg.length > 2) {
      return (
        <em key={sIdx} className="text-slate-300">
          {seg.slice(1, -1)}
        </em>
      );
    }
    return <React.Fragment key={sIdx}>{seg}</React.Fragment>;
  });
}

function renderFormattedProse(text: string) {
  const parts = text.split(/(```[\s\S]*?```)/g);
  return parts.map((part, idx) => {
    if (part.startsWith("```") && part.endsWith("```")) {
      const inner = part.slice(3, -3);
      const firstNewline = inner.indexOf("\n");
      const codeBody = firstNewline >= 0 ? inner.slice(firstNewline + 1) : inner;
      return (
        <pre
          key={idx}
          dir="ltr"
          className="my-3 overflow-x-auto rounded-lg border border-white/10 bg-[#070A10] p-3.5 text-left font-mono text-xs leading-relaxed text-slate-200"
        >
          <code>{codeBody}</code>
        </pre>
      );
    }
    const lines = part.split("\n");
    return (
      <span key={idx} className="whitespace-pre-wrap">
        {lines.map((line, lIdx) => {
          if (line.startsWith("### ")) {
            return (
              <span key={lIdx} className="mb-1.5 mt-1 block text-base font-bold text-white">
                {renderInlineSegments(line.slice(4))}
              </span>
            );
          }
          return (
            <React.Fragment key={lIdx}>
              {renderInlineSegments(line)}
              {lIdx < lines.length - 1 && <br />}
            </React.Fragment>
          );
        })}
      </span>
    );
  });
}

export default function OfflineChatView() {
  const [sessionId] = useState(() => "llm_" + Math.random().toString(36).slice(2, 9));
  const [style, setStyle] = useState<ResponseStyle>("auto");
  const [temperature, setTemperature] = useState<number>(0.18);
  const [dialectVoice, setDialectVoice] = useState("ar-EG");
  const [listening, setListening] = useState(false);
  const [activeTopic, setActiveTopic] = useState<string | null>(null);
  const [compressionEnabled, setCompressionEnabled] = useState(true);
  const [showAllHistory, setShowAllHistory] = useState(false);
  const [expandedInspectorId, setExpandedInspectorId] = useState<string | null>(null);
  const [compressedSummary, setCompressedSummary] = useState<string | null>(null);
  const [compressionStats, setCompressionStats] = useState<CompressionStats>({
    enabled: true,
    activeTurnsInWindow: 0,
    compressedTurns: 0,
    savedRatioPct: 0,
  });
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [messages, setMessages] = useState<ChatEntry[]>([
    {
      id: "llm_welcome",
      role: "assistant",
      content:
        "أهلاً بك! أنا **نواة (NawaLM-Transformer)** — نموذج لغوي عصبي حقيقي بمعمارية Transformer سببية وذاكرة KV-Cache ومحلل BPE، مدرّب بالانتشار العكسي وأوزانه محفوظة في `nawa_llm.bin` ويعمل أوفلاين بالكامل مع **ضغط النشاط** لتقليل اللاج.\n\nاسألني في البرمجة والذكاء الاصطناعي، أو افتح تفاصيل احتمالات التوكن بعد كل رد لتشاهد التوليد العصبي الفعلي رمزاً برمز.",
      suggestions: STARTER_PROMPTS,
    },
  ]);

  const bottomRef = useRef<HTMLDivElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: compressionEnabled ? "auto" : "smooth" });
  }, [messages.length, sending, compressionEnabled]);

  const hiddenCount =
    compressionEnabled && !showAllHistory && messages.length > UI_WINDOW_LIMIT
      ? messages.length - UI_WINDOW_LIMIT
      : 0;

  const visibleMessages = useMemo(() => {
    if (hiddenCount > 0) {
      return messages.slice(-UI_WINDOW_LIMIT);
    }
    return messages;
  }, [messages, hiddenCount]);

  const toggleCompression = async () => {
    const next = !compressionEnabled;
    setCompressionEnabled(next);
    if (next) setShowAllHistory(false);
    try {
      const res = await fetch("/api/llm/compress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ session_id: sessionId, compressionEnabled: next }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.compressionStats) setCompressionStats(data.compressionStats);
        if (data.compressedSummary !== undefined) setCompressedSummary(data.compressedSummary);
      }
    } catch {
      // Keep optimistic toggle state
    }
  };

  const stopGeneration = () => {
    abortRef.current?.abort();
    abortRef.current = null;
    setSending(false);
  };

  const sendMessage = async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if (!text || sending) return;
    if (!overrideText) setInput("");

    const userMsgId = "u_" + Date.now();
    const assistantMsgId = "a_" + (Date.now() + 1);

    setMessages((prev) => [
      ...prev,
      { id: userMsgId, role: "user", content: text },
      { id: assistantMsgId, role: "assistant", content: "" },
    ]);
    setSending(true);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      const res = await fetch("/api/llm/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          session_id: sessionId,
          style,
          temperature,
          topK: 6,
          compressionEnabled,
        }),
        signal: controller.signal,
      });

      if (!res.ok || !res.body) {
        const errBody = await res.json().catch(() => ({}));
        throw new Error(errBody.detail || "تعذر الاتصال بمحرك التوليد المحلي");
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let sepIndex = buffer.indexOf("\n\n");
        while (sepIndex !== -1) {
          const rawEvent = buffer.slice(0, sepIndex).trim();
          buffer = buffer.slice(sepIndex + 2);
          if (rawEvent.startsWith("data:")) {
            const payloadStr = rawEvent.slice(5).trim();
            if (payloadStr) {
              const evt = JSON.parse(payloadStr);
              if (evt.type === "meta") {
                if (evt.topic) setActiveTopic(evt.topic);
                if (evt.compressionStats) setCompressionStats(evt.compressionStats);
                if (evt.compressedSummary !== undefined) setCompressedSummary(evt.compressedSummary);
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantMsgId
                      ? {
                          ...m,
                          meta: {
                            dialect: evt.dialect,
                            topic: evt.topic,
                            questionType: evt.analysis?.questionType,
                            attentionScore: evt.attentionMatch?.score,
                            wasmMs: evt.wasmInferenceMs,
                            neural: evt.neuralTelemetry,
                          },
                        }
                      : m
                  )
                );
              } else if (evt.type === "token") {
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantMsgId ? { ...m, content: m.content + evt.chunk } : m
                  )
                );
              } else if (evt.type === "done") {
                if (evt.compressionStats) setCompressionStats(evt.compressionStats);
                if (evt.compressedSummary !== undefined) setCompressedSummary(evt.compressedSummary);
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantMsgId ? { ...m, suggestions: evt.suggestions } : m
                  )
                );
              } else if (evt.type === "error") {
                throw new Error(evt.detail || "خطأ أثناء البث");
              }
            }
          }
          sepIndex = buffer.indexOf("\n\n");
        }
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId && !m.content
              ? { ...m, content: "تم إيقاف التوليد." }
              : m
          )
        );
      } else {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  error: err instanceof Error ? err.message : "خطأ غير متوقع",
                }
              : m
          )
        );
      }
    } finally {
      abortRef.current = null;
      setSending(false);
    }
  };

  const resetConversation = async () => {
    stopGeneration();
    await fetch("/api/llm/reset", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: sessionId }),
    });
    setActiveTopic(null);
    setCompressedSummary(null);
    setShowAllHistory(false);
    setExpandedInspectorId(null);
    setCompressionStats({
      enabled: compressionEnabled,
      activeTurnsInWindow: 0,
      compressedTurns: 0,
      savedRatioPct: 0,
    });
    setMessages([
      {
        id: "reset_" + Date.now(),
        role: "assistant",
        content: "تم بدء محادثة جديدة بسياق نظيف وذاكرة KV-Cache فارغة. عمَّ تحب أن نتحدث الآن؟",
        suggestions: STARTER_PROMPTS,
      },
    ]);
  };

  const toggleVoice = () => {
    const win = window as unknown as {
      SpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        onend: () => void;
        onerror: () => void;
        start: () => void;
      };
      webkitSpeechRecognition?: new () => {
        lang: string;
        interimResults: boolean;
        onresult: (e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void;
        onend: () => void;
        onerror: () => void;
        start: () => void;
      };
    };
    const SR = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!SR) return;
    const rec = new SR();
    rec.lang = dialectVoice;
    rec.interimResults = false;
    setListening(true);
    rec.onresult = (e) => {
      const t = e.results[0]?.[0]?.transcript || "";
      setInput((prev) => (prev ? prev + " " + t : t));
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    rec.start();
  };

  return (
    <div className="flex h-[calc(100vh-65px)] flex-col bg-[#0B0F17]">
      {/* Conversational Context & Neural Activity Compression Bar */}
      <div className="border-b border-white/10 bg-[#111827] px-6 py-2.5">
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="font-semibold text-white">NawaLM-Transformer</span>
            {activeTopic && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-blue-300">الموضوع: {activeTopic}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              نافذة {compressionStats.activeTurnsInWindow}/6 · مضغوط {compressionStats.compressedTurns} · توفير{" "}
              {compressionStats.savedRatioPct}%
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={toggleCompression}
              className={`inline-flex items-center gap-1.5 rounded-md border px-2.5 py-1 text-xs transition-colors whitespace-nowrap shrink-0 ${
                compressionEnabled
                  ? "border-blue-500/40 bg-blue-500/10 text-blue-300 hover:bg-blue-500/20"
                  : "border-white/10 bg-[#0B0F17] text-slate-400 hover:border-white/25 hover:text-white"
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>ضغط النشاط: {compressionEnabled ? "مفعّل" : "متوقف"}</span>
            </button>

            <select
              aria-label="درجة الحرارة Sampling Temperature"
              value={temperature}
              onChange={(e) => setTemperature(Number(e.target.value))}
              className="rounded-md border border-white/10 bg-[#0B0F17] px-2.5 py-1 text-xs text-slate-200 focus:border-blue-500 focus:outline-none whitespace-nowrap shrink-0"
            >
              <option value={0.1}>حرارة: 0.10 (دقيق)</option>
              <option value={0.18}>حرارة: 0.18 (متوازن)</option>
              <option value={0.35}>حرارة: 0.35 (مرن)</option>
            </select>

            <select
              aria-label="أسلوب الرد"
              value={style}
              onChange={(e) => setStyle(e.target.value as ResponseStyle)}
              className="rounded-md border border-white/10 bg-[#0B0F17] px-2.5 py-1 text-xs text-slate-200 focus:border-blue-500 focus:outline-none whitespace-nowrap shrink-0"
            >
              <option value="auto">الأسلوب: تلقائي</option>
              <option value="simple">الأسلوب: مبسّط</option>
              <option value="detailed">الأسلوب: مفصّل</option>
              <option value="concise">الأسلوب: مختصر</option>
            </select>

            <button
              type="button"
              onClick={resetConversation}
              className="inline-flex items-center gap-1.5 rounded-md border border-white/10 bg-[#0B0F17] px-2.5 py-1 text-xs text-slate-300 hover:border-white/25 hover:text-white whitespace-nowrap shrink-0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>محادثة جديدة</span>
            </button>
          </div>
        </div>
      </div>

      {/* Centered Clean Conversation Thread */}
      <div className="flex-1 overflow-y-auto px-4 py-6 sm:px-6">
        <div className="mx-auto flex max-w-3xl flex-col gap-5">
          {hiddenCount > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-white/10 bg-[#111827] px-4 py-2.5 text-xs text-slate-400">
              <div className="flex flex-col gap-0.5">
                <span className="text-slate-200">
                  تم ضغط {hiddenCount} رسائل قديمة من العرض لتقليل اللاج والحفاظ على سرعة الواجهة.
                </span>
                {compressedSummary && (
                  <span className="text-[11px] text-slate-400">ملخص السياق: {compressedSummary}</span>
                )}
              </div>
              <button
                type="button"
                onClick={() => setShowAllHistory(true)}
                className="rounded border border-white/10 bg-[#0B0F17] px-2.5 py-1 text-xs text-blue-300 hover:border-blue-500/40 whitespace-nowrap shrink-0"
              >
                عرض السجل الكامل
              </button>
            </div>
          )}

          {compressionEnabled && showAllHistory && messages.length > UI_WINDOW_LIMIT && (
            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setShowAllHistory(false)}
                className="rounded border border-white/10 bg-[#111827] px-3 py-1 text-xs text-slate-300 hover:border-white/25 hover:text-white whitespace-nowrap shrink-0"
              >
                إعادة طي الرسائل القديمة لتقليل اللاج
              </button>
            </div>
          )}

          {visibleMessages.map((msg, idx) => {
            const neural = msg.meta?.neural;
            const isExpanded = expandedInspectorId === msg.id;

            return (
              <div
                key={msg.id}
                className={`rounded-xl border p-4 sm:p-5 text-[15px] leading-relaxed ${
                  msg.role === "user"
                    ? "self-start border-blue-500/30 bg-[#151E2E] text-slate-100 max-w-[85%]"
                    : "self-end w-full border-white/10 bg-[#111827] text-slate-200"
                }`}
              >
                {msg.meta && (
                  <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-2 text-xs text-slate-400">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span>اللهجة: {msg.meta.dialect}</span>
                      {msg.meta.questionType && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{QUESTION_TYPE_LABELS[msg.meta.questionType] || msg.meta.questionType}</span>
                        </>
                      )}
                      {neural && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono tabular-nums">
                            {neural.tokensPerSec} tok/s · PPL {neural.perplexity} · KV{" "}
                            {neural.kvCompression.activeKvSlots} slots
                          </span>
                        </>
                      )}
                    </div>

                    {neural && neural.topStepCandidates.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setExpandedInspectorId(isExpanded ? null : msg.id)}
                        className="inline-flex items-center gap-1 text-[11px] text-blue-300 hover:text-blue-200 whitespace-nowrap shrink-0"
                      >
                        <span>احتمالات التوكن</span>
                        {isExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                      </button>
                    )}
                  </div>
                )}

                {isExpanded && neural && (
                  <div className="mb-3 rounded-lg border border-white/10 bg-[#0B0F17] p-3 text-xs">
                    <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-slate-400">
                      <span>
                        توزيع احتمالات Softmax الفعلي ({neural.nLayers} Layers · {neural.nHeads} Heads ·{" "}
                        {neural.totalParams.toLocaleString()} params · {neural.trainedEpochs} epochs)
                      </span>
                      <span className="font-mono tabular-nums" dir="ltr">
                        {neural.generatedTokens} tokens
                      </span>
                    </div>
                    <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                      {neural.topStepCandidates.slice(0, 6).map((step, sIdx) => (
                        <div
                          key={sIdx}
                          className="flex items-center justify-between gap-2 rounded border border-white/5 bg-[#111827] px-2.5 py-1.5"
                        >
                          <span className="font-mono text-slate-200">
                            #{sIdx + 1}: «{step.chosen}»
                          </span>
                          <span className="font-mono tabular-nums text-emerald-400" dir="ltr">
                            {step.chosenProb}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {msg.error ? (
                  <div className="text-sm text-red-400">{msg.error}</div>
                ) : msg.content ? (
                  <div>{renderFormattedProse(msg.content)}</div>
                ) : (
                  <div className="text-sm text-slate-400">جاري الاستدلال بالمحول العصبي رمزاً برمز...</div>
                )}

                {msg.role === "assistant" &&
                  idx === visibleMessages.length - 1 &&
                  !sending &&
                  msg.suggestions &&
                  msg.suggestions.length > 0 && (
                    <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-white/10 pt-3">
                      {msg.suggestions.map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => sendMessage(s)}
                          className="rounded-lg border border-white/10 bg-[#0B0F17] px-3 py-1.5 text-xs text-slate-300 transition-colors hover:border-blue-500/40 hover:text-white"
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  )}
              </div>
            );
          })}
          <div ref={bottomRef} />
        </div>
      </div>

      {/* Centered Composer */}
      <div className="border-t border-white/10 bg-[#111827] px-4 py-4 sm:px-6">
        <div className="mx-auto flex max-w-3xl flex-col gap-2 sm:flex-row sm:items-end">
          <div className="flex items-center gap-2">
            <select
              aria-label="لهجة الإدخال الصوتي"
              value={dialectVoice}
              onChange={(e) => setDialectVoice(e.target.value)}
              className="h-11 rounded-lg border border-white/10 bg-[#0B0F17] px-3 text-xs text-slate-200 focus:border-blue-500 focus:outline-none"
            >
              {DIALECT_VOICES.map((d) => (
                <option key={d.code} value={d.code}>
                  صوت: {d.label}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={toggleVoice}
              className={`inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border transition-colors ${
                listening
                  ? "border-red-500 bg-red-500/15 text-red-400"
                  : "border-white/10 bg-[#0B0F17] text-slate-300 hover:border-white/25 hover:text-white"
              }`}
              title="تحدث بالصوت"
            >
              {listening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </button>
          </div>

          <textarea
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder="تحدث مع NawaLM-Transformer أوفلاين..."
            className="min-h-[44px] max-h-36 flex-1 resize-none rounded-lg border border-white/10 bg-[#0B0F17] px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-blue-500 focus:outline-none"
          />

          {sending ? (
            <button
              type="button"
              onClick={stopGeneration}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-lg border border-red-500/40 bg-red-500/15 px-5 text-sm font-semibold text-red-300 transition-colors hover:bg-red-500/25 whitespace-nowrap shrink-0"
            >
              <Square className="h-3.5 w-3.5" />
              <span>إيقاف</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={!input.trim()}
              onClick={() => sendMessage()}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-blue-600 px-5 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:cursor-not-allowed disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Send className="h-4 w-4" />
              <span>إرسال</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
