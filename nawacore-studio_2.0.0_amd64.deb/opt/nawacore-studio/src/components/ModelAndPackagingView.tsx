import React, { useState } from "react";
import ModelArchitectureView from "./ModelArchitectureView.tsx";
import PackagingView from "./PackagingView.tsx";

export default function ModelAndPackagingView() {
  const [subTab, setSubTab] = useState<"model" | "packaging">("model");

  return (
    <div>
      <div className="border-b border-white/10 bg-[#111827] px-6 py-2.5">
        <div className="mx-auto flex max-w-6xl items-center gap-2">
          <button
            type="button"
            onClick={() => setSubTab("model")}
            className={`rounded-md px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subTab === "model"
                ? "bg-blue-600 text-white"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
          >
            معمارية النموذج والتدريب
          </button>
          <button
            type="button"
            onClick={() => setSubTab("packaging")}
            className={`rounded-md px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
              subTab === "packaging"
                ? "bg-blue-600 text-white"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
          >
            ملفات التثبيت والتصدير (DEB / RUN / PYZ / EXE / APK)
          </button>
        </div>
      </div>

      {subTab === "model" ? <ModelArchitectureView /> : <PackagingView />}
    </div>
  );
}
