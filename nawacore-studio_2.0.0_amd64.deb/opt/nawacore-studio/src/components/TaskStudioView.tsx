import React, { useState } from "react";
import {
  Bug,
  Cpu,
  Database,
  FileCode2,
  Play,
  Server,
  ShieldCheck,
  Terminal,
} from "lucide-react";

type IsolatedTaskId = "apis" | "databases" | "security" | "algorithms" | "debugger";

interface TaskRunState {
  busy: boolean;
  reply: string | null;
  planSteps: string[];
  steps: Array<{ tool: string; arguments: string; output: string }>;
  generatedFile: string | null;
  fileContent: string | null;
  error: string | null;
  inferenceMs: number | null;
}

const INITIAL_TASK_STATE: TaskRunState = {
  busy: false,
  reply: null,
  planSteps: [],
  steps: [],
  generatedFile: null,
  fileContent: null,
  error: null,
  inferenceMs: null,
};

const TASK_TABS: Array<{
  id: IsolatedTaskId;
  label: string;
  title: string;
  description: string;
  scope: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  {
    id: "apis",
    label: "بناء APIs",
    title: "مهمة معزولة: بناء خوادم REST API واختبارها",
    description: "توليد واجهة برمجية كاملة بـ Python أو Node.js مع اختبارات وحدة وتنفيذ فوري.",
    scope: "create_fastapi_api",
    icon: Server,
  },
  {
    id: "databases",
    label: "قواعد SQLite",
    title: "مهمة معزولة: تصميم قواعد بيانات SQLite",
    description: "بناء جداول وفهارس بحث مع استعلامات محمية ضد SQL Injection واختبارات تكامل.",
    scope: "create_database_app",
    icon: Database,
  },
  {
    id: "security",
    label: "الأمان والمصادقة",
    title: "مهمة معزولة: التشفير والمصادقة الآمنة",
    description: "توليد وحدة تجزئة PBKDF2-SHA256 وتوكنات HMAC-SHA256 مقاومة للتلاعب.",
    scope: "create_auth_security",
    icon: ShieldCheck,
  },
  {
    id: "algorithms",
    label: "الخوارزميات و C++",
    title: "مهمة معزولة: الخوارزميات عالية الأداء",
    description: "توليد واختبار خوارزميات الفرز السريعة أو نوى C++20 بتعليمات AVX2.",
    scope: "create_algorithm_bench",
    icon: Cpu,
  },
  {
    id: "debugger",
    label: "فحص وإصلاح الأخطاء",
    title: "مهمة معزولة: التشخيص والفحص النحوي الشامل",
    description: "فحص ملفات Python و JavaScript في بيئة العمل وتشغيل جميع الاختبارات المكتشفة.",
    scope: "debug_and_fix",
    icon: Bug,
  },
];

const DOMAINS = [
  { id: "المنتجات", label: "المنتجات" },
  { id: "الموظفين", label: "الموظفين" },
  { id: "الطلاب", label: "الطلاب" },
  { id: "الفواتير", label: "الفواتير" },
  { id: "الطلبات", label: "الطلبات" },
  { id: "المهام", label: "المهام" },
];

export default function TaskStudioView() {
  const [activeTask, setActiveTask] = useState<IsolatedTaskId>("apis");

  // Isolated per-task state dictionary so switching tabs never loses or mixes task outputs
  const [taskStates, setTaskStates] = useState<Record<IsolatedTaskId, TaskRunState>>({
    apis: { ...INITIAL_TASK_STATE },
    databases: { ...INITIAL_TASK_STATE },
    security: { ...INITIAL_TASK_STATE },
    algorithms: { ...INITIAL_TASK_STATE },
    debugger: { ...INITIAL_TASK_STATE },
  });

  // Per-task interactive form controls
  const [apiDomain, setApiDomain] = useState("المنتجات");
  const [apiRuntime, setApiRuntime] = useState<"python" | "node">("python");
  const [dbDomain, setDbDomain] = useState("المنتجات");
  const [customPrompts, setCustomPrompts] = useState<Record<IsolatedTaskId, string>>({
    apis: "",
    databases: "",
    security: "",
    algorithms: "",
    debugger: "",
  });

  const currentTabMeta = TASK_TABS.find((t) => t.id === activeTask)!;
  const currentState = taskStates[activeTask];

  const executeIsolatedTask = async (taskId: IsolatedTaskId, prompt: string, scope: string) => {
    setTaskStates((prev) => ({
      ...prev,
      [taskId]: { ...prev[taskId], busy: true, error: null },
    }));

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: prompt,
          session_id: `isolated_task_${taskId}`,
          taskScope: scope,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "تعذر تنفيذ المهمة");

      const targetFile: string | null = data.activeContext?.lastFile || null;
      let fileContent: string | null = null;
      if (targetFile) {
        try {
          const fRes = await fetch(`/api/file?path=${encodeURIComponent(targetFile)}`);
          if (fRes.ok) {
            const fData = await fRes.json();
            fileContent = fData.content;
          }
        } catch {
          // ignore preview error
        }
      }

      setTaskStates((prev) => ({
        ...prev,
        [taskId]: {
          busy: false,
          reply: data.reply,
          planSteps: data.planSteps || [],
          steps: data.steps || [],
          generatedFile: targetFile,
          fileContent,
          error: null,
          inferenceMs: data.prediction?.wasmInferenceMs ?? null,
        },
      }));
    } catch (err) {
      setTaskStates((prev) => ({
        ...prev,
        [taskId]: {
          ...prev[taskId],
          busy: false,
          error: err instanceof Error ? err.message : "خطأ غير متوقع",
        },
      }));
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6 p-6 lg:p-8">
      {/* Section Heading & Isolated Task Switcher */}
      <div className="border-b border-white/10 pb-5">
        <h1 className="text-2xl font-bold text-white" style={{ textWrap: "balance" }}>
          استوديو المهام المعزولة
        </h1>
        <p className="mt-1.5 text-sm text-slate-400">
          كل مهمة برمجية معزولة في تبويبها المستقل وسياقها الخاص مع تنفيذ واختبار فعلي داخل بيئة العمل.
        </p>

        <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-white/10 pt-4">
          {TASK_TABS.map((tab) => {
            const Icon = tab.icon;
            const active = activeTask === tab.id;
            const hasDone = Boolean(taskStates[tab.id].reply);
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTask(tab.id)}
                className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? "border-blue-500 bg-blue-600 text-white"
                    : "border-white/10 bg-[#111827] text-slate-300 hover:border-white/25 hover:text-white"
                }`}
              >
                <Icon className="h-4 w-4" />
                <span>{tab.label}</span>
                {hasDone && !active && <span className="text-[11px] text-emerald-400">· منجز</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Isolated Task Panel */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[400px_1fr]">
        {/* Left Control Panel */}
        <div className="space-y-5 rounded-xl border border-white/10 bg-[#111827] p-5">
          <div>
            <h2 className="text-base font-semibold text-white">{currentTabMeta.title}</h2>
            <p className="mt-1 text-xs leading-relaxed text-slate-400">{currentTabMeta.description}</p>
          </div>

          <div className="border-t border-white/10 pt-4 space-y-4">
            {activeTask === "apis" && (
              <>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-slate-300">مجال البيانات (Entity)</label>
                  <div className="grid grid-cols-3 gap-2">
                    {DOMAINS.map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => setApiDomain(d.id)}
                        className={`rounded-md border px-2.5 py-2 text-xs font-medium transition-colors ${
                          apiDomain === d.id
                            ? "border-blue-500 bg-blue-600/20 text-blue-200"
                            : "border-white/10 bg-[#0B0F17] text-slate-400 hover:text-white"
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-slate-300">بيئة التشغيل</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setApiRuntime("python")}
                      className={`rounded-md border px-3 py-2 text-xs font-medium ${
                        apiRuntime === "python"
                          ? "border-blue-500 bg-blue-600/20 text-blue-200"
                          : "border-white/10 bg-[#0B0F17] text-slate-400"
                      }`}
                    >
                      Python HTTP + unittest
                    </button>
                    <button
                      type="button"
                      onClick={() => setApiRuntime("node")}
                      className={`rounded-md border px-3 py-2 text-xs font-medium ${
                        apiRuntime === "node"
                          ? "border-blue-500 bg-blue-600/20 text-blue-200"
                          : "border-white/10 bg-[#0B0F17] text-slate-400"
                      }`}
                    >
                      Node.js + node:test
                    </button>
                  </div>
                </div>

                <button
                  type="button"
                  disabled={currentState.busy}
                  onClick={() =>
                    executeIsolatedTask(
                      "apis",
                      `اعملي API لـ ${apiDomain} بـ ${apiRuntime === "node" ? "Node.js" : "Python"} واختبره`,
                      "create_fastapi_api"
                    )
                  }
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-50"
                >
                  <Play className="h-4 w-4" />
                  <span>{currentState.busy ? "جاري البناء والاختبار..." : "بناء واختبار الـ API"}</span>
                </button>
              </>
            )}

            {activeTask === "databases" && (
              <>
                <div>
                  <label className="mb-1.5 block text-xs font-medium text-slate-300">الكيان (Table Schema)</label>
                  <div className="grid grid-cols-3 gap-2">
                    {DOMAINS.map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => setDbDomain(d.id)}
                        className={`rounded-md border px-2.5 py-2 text-xs font-medium transition-colors ${
                          dbDomain === d.id
                            ? "border-blue-500 bg-blue-600/20 text-blue-200"
                            : "border-white/10 bg-[#0B0F17] text-slate-400 hover:text-white"
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="button"
                  disabled={currentState.busy}
                  onClick={() =>
                    executeIsolatedTask(
                      "databases",
                      `اعملي قاعدة بيانات SQLite لـ ${dbDomain} واختبرها`,
                      "create_database_app"
                    )
                  }
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-50"
                >
                  <Play className="h-4 w-4" />
                  <span>{currentState.busy ? "جاري الإنشاء والاختبار..." : "إنشاء قاعدة SQLite واختبارها"}</span>
                </button>
              </>
            )}

            {activeTask === "security" && (
              <button
                type="button"
                disabled={currentState.busy}
                onClick={() =>
                  executeIsolatedTask(
                    "security",
                    "سويلي نظام مصادقة وتشفير كلمات المرور PBKDF2 وتوكنات HMAC واختبره",
                    "create_auth_security"
                  )
                }
                className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-50"
              >
                <Play className="h-4 w-4" />
                <span>{currentState.busy ? "جاري التوليد والاختبار..." : "توليد وحدة الأمان واختبارها"}</span>
              </button>
            )}

            {activeTask === "algorithms" && (
              <div className="space-y-2.5">
                <button
                  type="button"
                  disabled={currentState.busy}
                  onClick={() =>
                    executeIsolatedTask(
                      "algorithms",
                      "اعمل خوارزمية فرز سريعة واختبرها على 100 الف عنصر",
                      "create_algorithm_bench"
                    )
                  }
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-50"
                >
                  <Play className="h-4 w-4" />
                  <span>{currentState.busy ? "جاري التنفيذ..." : "بناء واختبار خوارزمية الفرز"}</span>
                </button>
                <button
                  type="button"
                  disabled={currentState.busy}
                  onClick={() =>
                    executeIsolatedTask(
                      "algorithms",
                      "اكتب نواة C++ سريعة بـ AVX2 تنجز 50 مليون عملية في الثانية",
                      "generate_native_kernel"
                    )
                  }
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-white/15 bg-[#0B0F17] px-4 text-xs font-semibold text-slate-200 transition-colors hover:border-blue-500 disabled:opacity-50"
                >
                  <Cpu className="h-4 w-4 text-blue-400" />
                  <span>توليد نواة C++ AVX2</span>
                </button>
              </div>
            )}

            {activeTask === "debugger" && (
              <div className="space-y-2.5">
                <button
                  type="button"
                  disabled={currentState.busy}
                  onClick={() =>
                    executeIsolatedTask(
                      "debugger",
                      "افحص ملفات المشروع وشوف لو فيها اخطاء",
                      "debug_and_fix"
                    )
                  }
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 text-sm font-semibold text-white transition-colors hover:bg-blue-500 disabled:opacity-50"
                >
                  <Play className="h-4 w-4" />
                  <span>{currentState.busy ? "جاري الفحص..." : "فحص نحوّي وتشغيل كل الاختبارات"}</span>
                </button>
                <button
                  type="button"
                  disabled={currentState.busy}
                  onClick={() =>
                    executeIsolatedTask(
                      "debugger",
                      "اشرحلي معمارية المشروع واحصائيات الملفات",
                      "explain_architecture"
                    )
                  }
                  className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-lg border border-white/15 bg-[#0B0F17] px-4 text-xs font-semibold text-slate-200 transition-colors hover:border-blue-500 disabled:opacity-50"
                >
                  <span>تحليل إحصائيات وهيكلة الكود</span>
                </button>
              </div>
            )}

            {/* Scoped Custom Prompt Inside the Isolated Task */}
            <form
              className="border-t border-white/10 pt-4 space-y-2"
              onSubmit={(e) => {
                e.preventDefault();
                const text = customPrompts[activeTask].trim();
                if (!text || currentState.busy) return;
                executeIsolatedTask(activeTask, text, currentTabMeta.scope);
              }}
            >
              <label className="block text-xs text-slate-400">
                أو اكتب أمراً مخصصاً داخل نطاق هذه المهمة:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customPrompts[activeTask]}
                  onChange={(e) =>
                    setCustomPrompts((prev) => ({ ...prev, [activeTask]: e.target.value }))
                  }
                  placeholder="أمر باللهجة العربية..."
                  className="flex-1 rounded-lg border border-white/10 bg-[#0B0F17] px-3 py-2 text-xs text-white focus:border-blue-500 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={currentState.busy || !customPrompts[activeTask].trim()}
                  className="rounded-lg border border-white/15 bg-[#0B0F17] px-3 py-2 text-xs font-medium text-white hover:border-blue-500 disabled:opacity-40"
                >
                  تنفيذ
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Right Isolated Output & Code Inspector */}
        <div className="space-y-5 rounded-xl border border-white/10 bg-[#111827] p-5">
          {currentState.error && (
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300">
              {currentState.error}
            </div>
          )}

          {!currentState.reply && !currentState.busy ? (
            <div className="flex h-full min-h-[320px] flex-col items-center justify-center text-center text-sm text-slate-400">
              <Terminal className="mb-3 h-8 w-8 text-slate-600" />
              <p>هذه المساحة مخصصة لمخرجات مهمة «{currentTabMeta.label}» فقط.</p>
              <p className="mt-1 text-xs text-slate-500">
                اضغط على زر التنفيذ لتوليد الكود واختباره فعلياً في بيئة العمل.
              </p>
            </div>
          ) : currentState.busy ? (
            <div className="space-y-3 py-8">
              <div className="h-6 w-1/2 animate-pulse rounded bg-white/5" />
              <div className="h-32 animate-pulse rounded bg-white/5" />
              <div className="h-40 animate-pulse rounded bg-white/5" />
            </div>
          ) : (
            <div className="space-y-4">
              {currentState.inferenceMs !== null && (
                <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-2 text-xs text-slate-400">
                  <span>النطاق المعزول: {currentTabMeta.label}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">WASM {currentState.inferenceMs} ms</span>
                  {currentState.generatedFile && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-blue-300" dir="ltr">
                        {currentState.generatedFile}
                      </span>
                    </>
                  )}
                </div>
              )}

              {currentState.planSteps.length > 0 && (
                <div className="rounded-lg border border-white/10 bg-[#0B0F17] p-3 text-xs">
                  <div className="mb-1 font-semibold text-blue-300">خطوات التنفيذ</div>
                  <ol className="list-inside list-decimal space-y-0.5 text-slate-300">
                    {currentState.planSteps.map((s, idx) => (
                      <li key={idx}>{s}</li>
                    ))}
                  </ol>
                </div>
              )}

              {currentState.steps.length > 0 && (
                <div className="space-y-2" dir="ltr">
                  {currentState.steps
                    .filter((s) => s.tool === "run_command")
                    .map((s, idx) => (
                      <div key={idx} className="rounded-lg border border-emerald-500/20 bg-[#070A10] p-3 text-left">
                        <div className="font-mono text-[11px] font-semibold text-emerald-400">
                          $ {JSON.parse(s.arguments).command}
                        </div>
                        <pre className="mt-1.5 max-h-48 overflow-auto font-mono text-[11px] text-slate-200">
                          {s.output}
                        </pre>
                      </div>
                    ))}
                </div>
              )}

              {currentState.fileContent && (
                <div className="overflow-hidden rounded-lg border border-white/10 bg-[#070A10]">
                  <div
                    dir="ltr"
                    className="flex items-center gap-2 border-b border-white/10 bg-[#0B0F17] px-3 py-2 font-mono text-xs text-slate-300"
                  >
                    <FileCode2 className="h-3.5 w-3.5 text-blue-400" />
                    <span>{currentState.generatedFile}</span>
                  </div>
                  <pre
                    dir="ltr"
                    className="max-h-80 overflow-auto p-3 text-left font-mono text-xs leading-relaxed text-slate-200"
                  >
                    {currentState.fileContent}
                  </pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
