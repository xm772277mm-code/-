import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { execSync } from "node:child_process";
import express from "express";
import {
  ensureWorkspaceSeeded,
  listFiles,
  runCustomAgent,
  safeWorkspacePath,
  type AgentSessionContext,
} from "./src/engine/agentRuntime.ts";
import {
  getNawaOfflineLLM,
  type OfflineLLMContext,
  type ResponseStyle,
} from "./src/llm/NawaOfflineLLM.ts";
import {
  fineTuneNawaTransformer,
  getNawaTransformerLM,
} from "./src/llm/NawaTransformerLM.ts";
import {
  getNawaModel,
  HIDDEN1_DIM,
  HIDDEN2_DIM,
  INPUT_DIM,
  INTENTS,
  OUTPUT_DIM,
  type AgentIntentId,
} from "./src/engine/nawaModel.ts";
import { getWasmKernel } from "./src/engine/wasmKernel.ts";
import { buildZipArchive } from "./src/engine/zipBuilder.ts";
import {
  buildAndroidApkKitEntries,
  buildWindowsExeKitEntries,
  generateAndroidNeonCpp,
  generateWeightsHeader,
  generateWindowsCppEngine,
} from "./src/engine/nativeTemplates.ts";

const PORT = 3000;
const SESSIONS = new Map<
  string,
  { history: Array<{ role: string; content: string }>; context: AgentSessionContext }
>();
const LLM_SESSIONS = new Map<string, OfflineLLMContext>();

function hasBinary(cmd: string): boolean {
  try {
    execSync(`command -v ${cmd}`, { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
}

async function startServer() {
  ensureWorkspaceSeeded();
  // Warm up Intent MLP, WASM kernel, and NawaLM Transformer checkpoint on boot
  const model = getNawaModel();
  await model.syncToWasm();
  const kernel = await getWasmKernel();
  getNawaTransformerLM();

  const app = express();
  app.use(express.json({ limit: "2mb" }));

  // Workspace file listing
  app.get("/api/files", (_req, res) => {
    res.json({ tree: listFiles(".") });
  });

  // Workspace file reader
  app.get("/api/file", (req, res) => {
    const relPath = String(req.query.path || "");
    if (!relPath) {
      res.status(400).json({ detail: "مسار الملف مطلوب" });
      return;
    }
    try {
      const target = safeWorkspacePath(relPath);
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
        res.status(404).json({ detail: "الملف غير موجود" });
        return;
      }
      res.json({ path: relPath, content: fs.readFileSync(target, "utf-8") });
    } catch (err) {
      res.status(403).json({ detail: err instanceof Error ? err.message : "مسار غير مصرح به" });
    }
  });

  // Standalone Offline Language Model (Decoupled from IDE Workspace)
  const getOrCreateLlmSession = (sessionId: string, style: ResponseStyle, compressionEnabled?: boolean): OfflineLLMContext => {
    let ctx = LLM_SESSIONS.get(sessionId);
    if (!ctx) {
      ctx = {
        activeTopic: null,
        lastEntities: [],
        lastUserDialect: "فصحى / تقني",
        history: [],
        compressedSummary: null,
        compressedTurnsCount: 0,
        compressionEnabled: typeof compressionEnabled === "boolean" ? compressionEnabled : true,
        preferredStyle: style,
      };
      LLM_SESSIONS.set(sessionId, ctx);
    }
    ctx.preferredStyle = style;
    if (typeof compressionEnabled === "boolean") {
      ctx.compressionEnabled = compressionEnabled;
    }
    return ctx;
  };

  app.post("/api/llm/reset", (req, res) => {
    const sessionId = String(req.body?.session_id || "default");
    LLM_SESSIONS.delete(sessionId);
    res.json({ status: "ok" });
  });

  app.post("/api/llm/compress", (req, res) => {
    const sessionId = String(req.body?.session_id || "default");
    const compressionEnabled =
      typeof req.body?.compressionEnabled === "boolean" ? req.body.compressionEnabled : true;
    const ctx = getOrCreateLlmSession(sessionId, "auto", compressionEnabled);
    const llm = getNawaOfflineLLM();
    const { savedRatioPct } = llm.compressContextIfNeeded(ctx);
    res.json({
      status: "ok",
      compressionStats: {
        enabled: ctx.compressionEnabled,
        activeTurnsInWindow: ctx.history.length,
        compressedTurns: ctx.compressedTurnsCount,
        savedRatioPct,
      },
      compressedSummary: ctx.compressedSummary,
    });
  });

  app.get("/api/llm/model-info", (_req, res) => {
    res.json(getNawaTransformerLM().getModelInfo());
  });

  app.post("/api/llm/train", (req, res) => {
    const prompt = String(req.body?.prompt || "").trim();
    const response = String(req.body?.response || "").trim();
    const topic = String(req.body?.topic || "custom").trim();
    const epochs = Number(req.body?.epochs || 12);
    if (!prompt || !response) {
      res.status(400).json({ detail: "يرجى إدخال السؤال التدريبي والإجابة المستهدفة" });
      return;
    }
    try {
      const result = fineTuneNawaTransformer(prompt, response, topic, epochs);
      res.json({ status: "ok", ...result });
    } catch (err) {
      res.status(500).json({ detail: err instanceof Error ? err.message : "فشل تدريب المحول" });
    }
  });

  app.post("/api/llm/chat", async (req, res) => {
    const message = String(req.body?.message || "").trim();
    const sessionId = String(req.body?.session_id || "default");
    const style = String(req.body?.style || "auto") as ResponseStyle;
    const compressionEnabled =
      typeof req.body?.compressionEnabled === "boolean" ? req.body.compressionEnabled : undefined;
    const temperature =
      typeof req.body?.temperature === "number" ? req.body.temperature : undefined;
    const topK = typeof req.body?.topK === "number" ? req.body.topK : undefined;
    if (!message) {
      res.status(400).json({ detail: "الرسالة فارغة" });
      return;
    }
    try {
      const ctx = getOrCreateLlmSession(sessionId, style, compressionEnabled);
      const llm = getNawaOfflineLLM();
      const result = await llm.generateReply(message, ctx, { temperature, topK });
      res.json({
        ...result,
        compressedSummary: ctx.compressedSummary,
      });
    } catch (err) {
      res.status(500).json({ detail: err instanceof Error ? err.message : "خطأ في النموذج اللغوي" });
    }
  });

  app.post("/api/llm/stream", async (req, res) => {
    const message = String(req.body?.message || "").trim();
    const sessionId = String(req.body?.session_id || "default");
    const style = String(req.body?.style || "auto") as ResponseStyle;
    const compressionEnabled =
      typeof req.body?.compressionEnabled === "boolean" ? req.body.compressionEnabled : undefined;
    const temperature =
      typeof req.body?.temperature === "number" ? req.body.temperature : undefined;
    const topK = typeof req.body?.topK === "number" ? req.body.topK : undefined;
    if (!message) {
      res.status(400).json({ detail: "الرسالة فارغة" });
      return;
    }

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");

    let closed = false;
    res.on("close", () => {
      if (!res.writableEnded) {
        closed = true;
      }
    });

    try {
      const ctx = getOrCreateLlmSession(sessionId, style, compressionEnabled);
      const llm = getNawaOfflineLLM();
      const result = await llm.generateReply(message, ctx, { temperature, topK });

      if (closed) return;
      res.write(
        `data: ${JSON.stringify({
          type: "meta",
          topic: result.topic,
          dialect: result.dialect,
          intentCategory: result.intentCategory,
          analysis: result.analysis,
          attentionMatch: result.attentionMatch,
          compressionStats: result.compressionStats,
          neuralTelemetry: result.neuralTelemetry,
          compressedSummary: ctx.compressedSummary,
          wasmInferenceMs: result.wasmInferenceMs,
          tokensProcessed: result.tokensProcessed,
        })}\n\n`
      );

      // Stream smooth word-preserving chunks to eliminate UI lag on long replies
      const tokens = result.reply.match(/\S+\s*/g) || [result.reply];
      const chunkSize = 3;
      for (let i = 0; i < tokens.length; i += chunkSize) {
        if (closed) return;
        const chunk = tokens.slice(i, i + chunkSize).join("");
        res.write(`data: ${JSON.stringify({ type: "token", chunk })}\n\n`);
        await new Promise((r) => setTimeout(r, 12));
      }

      if (closed) return;
      res.write(
        `data: ${JSON.stringify({
          type: "done",
          suggestions: result.suggestions,
          compressionStats: result.compressionStats,
          compressedSummary: ctx.compressedSummary,
        })}\n\n`
      );
      res.end();
    } catch (err) {
      if (!closed) {
        res.write(
          `data: ${JSON.stringify({
            type: "error",
            detail: err instanceof Error ? err.message : "خطأ في البث",
          })}\n\n`
        );
        res.end();
      }
    }
  });

  // Reset IDE agent session
  app.post("/api/reset", (req, res) => {
    const sessionId = String(req.body?.session_id || "default");
    SESSIONS.delete(sessionId);
    res.json({ status: "ok" });
  });

  // Custom Local Neural Agent Chat (with persistent context memory + optional taskScope)
  app.post("/api/chat", async (req, res) => {
    const message = String(req.body?.message || "").trim();
    const sessionId = String(req.body?.session_id || "default");
    const taskScope = String(req.body?.taskScope || "auto") as AgentIntentId | "auto";
    if (!message) {
      res.status(400).json({ detail: "الرسالة فارغة" });
      return;
    }
    try {
      let session = SESSIONS.get(sessionId);
      if (!session) {
        session = {
          history: [],
          context: {
            lastFile: null,
            lastDomain: "tasks",
            lastDomainObj: { nameEn: "tasks", nameAr: "المهام", fields: ["title", "priority", "done"] },
            lastLanguage: "python",
            lastIntent: null,
            createdFiles: [],
            turnCount: 0,
          },
        };
        SESSIONS.set(sessionId, session);
      }
      session.history.push({ role: "user", content: message });
      const result = await runCustomAgent(message, session.context, taskScope);
      session.history.push({ role: "assistant", content: result.reply });
      if (session.history.length > 40) {
        session.history = session.history.slice(-40);
      }
      res.json(result);
    } catch (err) {
      res.status(500).json({ detail: err instanceof Error ? err.message : "خطأ داخلي في النموذج" });
    }
  });

  // Custom Model Inspection
  app.get("/api/model/info", (_req, res) => {
    res.json({
      name: "NawaCore-50M",
      architecture: `${INPUT_DIM} -> ${HIDDEN1_DIM} -> ${HIDDEN2_DIM} -> ${OUTPUT_DIM}`,
      layers: [
        { name: "Input (Dialect + Trigram Hash)", dim: INPUT_DIM, params: 0 },
        { name: "Dense + ReLU (WASM 4x Unrolled)", dim: HIDDEN1_DIM, params: INPUT_DIM * HIDDEN1_DIM + HIDDEN1_DIM },
        { name: "Dense + ReLU (WASM 4x Unrolled)", dim: HIDDEN2_DIM, params: HIDDEN1_DIM * HIDDEN2_DIM + HIDDEN2_DIM },
        { name: "Output + Softmax", dim: OUTPUT_DIM, params: HIDDEN2_DIM * OUTPUT_DIM + OUTPUT_DIM },
      ],
      totalParams: model.totalParams,
      weightsSizeBytes: model.totalParams * 4 + 20,
      wasmSizeBytes: kernel.wasmBytes.byteLength,
      trainedEpochs: model.trainedEpochs,
      corpusCount: model.corpus.length,
      intents: INTENTS,
      lossHistory: model.lossHistory,
      sampleCorpus: model.corpus.slice(-18).reverse(),
    });
  });

  // Interactive Live Fine-Tuning
  app.post("/api/model/train", async (req, res) => {
    const text = String(req.body?.text || "").trim();
    const intent = String(req.body?.intent || "") as AgentIntentId;
    const dialect = String(req.body?.dialect || "مخصص").trim();
    if (!text || !INTENTS.some((i) => i.id === intent)) {
      res.status(400).json({ detail: "يرجى إدخال جملة تدريب صالحة واختيار النية البرمجية." });
      return;
    }
    const recent = model.addSampleAndRetrain(text, intent, dialect);
    await model.syncToWasm();
    res.json({
      status: "ok",
      trainedEpochs: model.trainedEpochs,
      corpusCount: model.corpus.length,
      recentStats: recent,
      lossHistory: model.lossHistory,
    });
  });

  // Real Server-Side WASM 50M+ ops/sec Benchmark
  app.post("/api/benchmark", (req, res) => {
    const requestedOps = Number(req.body?.targetOps || 50_000_000);
    const clampedOps = Math.min(Math.max(requestedOps, 10_000_000), 500_000_000);
    const result = kernel.runBenchmark(clampedOps);
    res.json({
      ...result,
      runtime: `Node.js ${process.version} (${os.arch()}/${os.platform()})`,
      cpuModel: os.cpus()[0]?.model || "x86_64",
      cpuCores: os.cpus().length,
    });
  });

  // Packaging Toolchain Probe
  app.get("/api/packaging/toolchain", (_req, res) => {
    res.json({
      host: `${os.platform()} ${os.arch()} (${os.cpus().length} cores)`,
      compilers: {
        wasmEmitter: true,
        gcc: hasBinary("gcc") || hasBinary("g++"),
        mingwExe: hasBinary("x86_64-w64-mingw32-g++"),
        pyinstaller: hasBinary("pyinstaller"),
        gradleAndroid: hasBinary("gradle"),
        python3: hasBinary("python3"),
      },
      artifacts: [
        {
          id: "wasm",
          filename: "nawa_engine.wasm",
          sizeBytes: kernel.wasmBytes.byteLength,
          ready: true,
        },
        {
          id: "weights",
          filename: "nawa_weights.bin",
          sizeBytes: model.exportWeightsBinary().byteLength,
          ready: true,
        },
        {
          id: "exe-kit",
          filename: "NawaCore-Windows-EXE-Kit.zip",
          ready: true,
        },
        {
          id: "apk-kit",
          filename: "NawaCore-Android-APK-Kit.zip",
          ready: true,
        },
      ],
    });
  });

  // Preview generated native C++/JNI/Header source
  app.get("/api/packaging/preview", (req, res) => {
    const target = String(req.query.target || "windows");
    if (target === "windows") {
      res.json({ filename: "src/nawa_agent.cpp", language: "cpp", code: generateWindowsCppEngine() });
    } else if (target === "android") {
      res.json({ filename: "app/src/main/cpp/nawa_neon_jni.cpp", language: "cpp", code: generateAndroidNeonCpp() });
    } else {
      res.json({ filename: "src/nawa_weights.h", language: "cpp", code: generateWeightsHeader().slice(0, 6000) + "\n// ... (truncated preview, full weights included in download)" });
    }
  });

  // Download Real Artifacts (.wasm, .bin, .zip EXE kit, .zip APK kit)
  app.get("/api/packaging/download/:target", (req, res) => {
    const target = req.params.target;
    if (target === "wasm") {
      res.setHeader("Content-Type", "application/wasm");
      res.setHeader("Content-Disposition", 'attachment; filename="nawa_engine.wasm"');
      res.send(Buffer.from(kernel.wasmBytes));
      return;
    }
    if (target === "weights") {
      const bin = model.exportWeightsBinary();
      res.setHeader("Content-Type", "application/octet-stream");
      res.setHeader("Content-Disposition", 'attachment; filename="nawa_weights.bin"');
      res.send(Buffer.from(bin));
      return;
    }
    if (target === "exe-kit") {
      const zipBuf = buildZipArchive(buildWindowsExeKitEntries());
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="NawaCore-Windows-EXE-Kit.zip"');
      res.send(zipBuf);
      return;
    }
    if (target === "apk-kit") {
      const weightsBin = model.exportWeightsBinary();
      const zipBuf = buildZipArchive(buildAndroidApkKitEntries(weightsBin));
      res.setHeader("Content-Type", "application/zip");
      res.setHeader("Content-Disposition", 'attachment; filename="NawaCore-Android-APK-Kit.zip"');
      res.send(zipBuf);
      return;
    }
    const rootFiles: Record<string, { filename: string; mime: string }> = {
      deb: { filename: "nawacore-studio_2.0.0_amd64.deb", mime: "application/vnd.debian.binary-package" },
      run: { filename: "NawaCore-Setup.run", mime: "application/x-shellscript" },
      pyz: { filename: "NawaCore-Agent.pyz", mime: "application/octet-stream" },
      "llm-weights": { filename: "nawa_llm.bin", mime: "application/octet-stream" },
    };
    if (rootFiles[target]) {
      const filePath = path.resolve(process.cwd(), rootFiles[target].filename);
      if (fs.existsSync(filePath)) {
        res.setHeader("Content-Type", rootFiles[target].mime);
        res.setHeader("Content-Disposition", `attachment; filename="${rootFiles[target].filename}"`);
        res.sendFile(filePath);
        return;
      }
    }
    res.status(404).json({ detail: "الحزمة المطلوبة غير موجودة" });
  });

  if (process.env.NODE_ENV !== "production") {
    const { createServer } = await import("vite");
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), "dist");
    app.use(express.static(distDir));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NawaCore Studio listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
