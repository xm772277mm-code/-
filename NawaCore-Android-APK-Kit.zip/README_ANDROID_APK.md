# NawaCore-50M Android APK Build Kit (ARM64 NEON + JNI)
هذا المشروع يحتوي على نواة C++ محلية `libnawa_engine.so` مهيأة بمعالجات ARM64 NEON SIMD بالإضافة إلى أوزان النموذج المدربة `nawa_weights.bin`.

## خطوات استخراج ملف APK
1. افتح المجلد داخل Android Studio (مع تثبيت NDK و CMake).
2. أو من سطر الأوامر: `./gradlew assembleRelease`
3. ستجد ملف التطبيق الجاهز في: `app/build/outputs/apk/release/app-release.apk`
