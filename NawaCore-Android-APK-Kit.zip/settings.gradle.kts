rootProject.name = "NawaCoreAndroid"
include(":app")
