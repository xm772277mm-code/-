#include <jni.h>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <vector>
#if defined(__aarch64__)
#include <arm_neon.h>
#endif

extern "C" JNIEXPORT jdoubleArray JNICALL
Java_com_nawa_agent_NawaEngineBridge_benchmark50M(JNIEnv* env, jobject /* thiz */) {
    constexpr int N = 65536;
    constexpr int ROUNDS = 400; // 52,428,800 FLOPs
    std::vector<float> a(N, 1.001f);
    std::vector<float> b(N, 0.999f);

    auto t0 = std::chrono::high_resolution_clock::now();
    float total = 0.0f;
#if defined(__aarch64__)
    float32x4_t acc0 = vdupq_n_f32(0.0f);
    float32x4_t acc1 = vdupq_n_f32(0.0f);
    for (int r = 0; r < ROUNDS; ++r) {
        for (int i = 0; i < N; i += 8) {
            acc0 = vfmaq_f32(acc0, vld1q_f32(&a[i]), vld1q_f32(&b[i]));
            acc1 = vfmaq_f32(acc1, vld1q_f32(&a[i + 4]), vld1q_f32(&b[i + 4]));
        }
    }
    float32x4_t sum = vaddq_f32(acc0, acc1);
    total = vaddvq_f32(sum);
#else
    float acc0 = 0.0f, acc1 = 0.0f;
    for (int r = 0; r < ROUNDS; ++r) {
        for (int i = 0; i < N; i += 2) {
            acc0 += a[i] * b[i];
            acc1 += a[i + 1] * b[i + 1];
        }
    }
    total = acc0 + acc1;
#endif
    auto t1 = std::chrono::high_resolution_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    double totalOps = static_cast<double>(N) * 2.0 * ROUNDS;
    double opsPerSec = (totalOps / ms) * 1000.0;

    jdouble out[3] = { totalOps, ms, opsPerSec + (total * 0.0) };
    jdoubleArray result = env->NewDoubleArray(3);
    env->SetDoubleArrayRegion(result, 0, 3, out);
    return result;
}
