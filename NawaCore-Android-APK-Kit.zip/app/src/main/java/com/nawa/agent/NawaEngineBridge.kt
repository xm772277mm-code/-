package com.nawa.agent

object NawaEngineBridge {
    init {
        System.loadLibrary("nawa_engine")
    }
    external fun benchmark50M(): DoubleArray
}
