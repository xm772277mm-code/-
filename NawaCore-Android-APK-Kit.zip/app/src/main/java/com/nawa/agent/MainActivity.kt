package com.nawa.agent

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }
        val title = TextView(this).apply {
            text = "نواة NawaCore-50M — محرك ARM64 NEON المحلي"
            textSize = 20f
        }
        val output = TextView(this).apply {
            text = "اضغط لبدء اختبار 50 مليون عملية في الثانية عبر JNI C++"
            textSize = 15f
        }
        val btn = Button(this).apply {
            text = "تشغيل اختبار 50M/ث"
            setOnClickListener {
                val res = NawaEngineBridge.benchmark50M()
                output.text = "العمليات: ${res[0].toLong()}\nالزمن: ${"%.2f".format(res[1])} ms\nالسرعة: ${res[2].toLong()} ops/sec"
            }
        }
        layout.addView(title)
        layout.addView(btn)
        layout.addView(output)
        setContentView(layout)
    }
}
